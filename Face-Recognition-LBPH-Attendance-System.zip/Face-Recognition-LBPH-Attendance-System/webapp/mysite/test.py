import pickle
names = []
filename = "names.pkl"
f = open(filename, 'wb')
pickle.dump(names,f)
f.close()