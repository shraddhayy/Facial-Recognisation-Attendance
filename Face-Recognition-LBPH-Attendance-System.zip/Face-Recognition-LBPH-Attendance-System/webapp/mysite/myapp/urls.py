from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('faceRegistration/', views.faceRegistration, name='faceRegistration'),
]