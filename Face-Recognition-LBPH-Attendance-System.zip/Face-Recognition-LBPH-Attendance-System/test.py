import pickle
pickle_in = open("names.pkl", "rb")
pickledata = pickle.load(pickle_in)
print(pickledata)
#registereddoctors = pickledata.get('registereddoctors')
