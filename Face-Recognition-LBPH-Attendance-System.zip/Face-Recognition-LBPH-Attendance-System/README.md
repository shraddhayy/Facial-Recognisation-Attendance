# Face-Recognition-LPBH
Face recognition program using LBPH algo. Users can Register new faces and can run recognition.
